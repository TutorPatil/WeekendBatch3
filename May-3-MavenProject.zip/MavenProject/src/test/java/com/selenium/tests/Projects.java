package com.selenium.tests;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

import com.selenium.base.BaseClass;

public class Projects extends BaseClass{
	
	//@Test
	public static void scrollingTest() throws InterruptedException
	{
		driver.get("https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_win_scrollto2");
		
		driver.switchTo().frame("iframeResult");
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		
		js.executeScript("window.scrollBy(0,1000);");
		
		Thread.sleep(5000);
		
		js.executeScript("window.scrollBy(1000,2000);");
		
		js.executeScript("window.open('https://google.com','_');");
		
		Thread.sleep(5000);
		
		Set<String> winIds = driver.getWindowHandles();
		
		Iterator<String> itr = winIds.iterator();
		
		String firstWindowID = itr.next();
		
		String secondWindowID = itr.next();
		
		driver.switchTo().window(secondWindowID);
		
		Thread.sleep(2000);
		
		System.out.println(driver.getTitle());
		
		driver.switchTo().window(firstWindowID);
		
		Thread.sleep(2000);
		
		System.out.println(driver.getTitle());
		
		
		
		
		
		
		
		
	}

}
