package com.selenium.tests;

import java.io.File;

import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ExtentReportDemo {
	
	//@Test
	public static void extentReportDemo()
	{
		
		File f = new File("./src/test/results/suiteresults.html");
		
		//Step -1 Create the Object of ExtentHtmlReporter class
		ExtentHtmlReporter reporter = new ExtentHtmlReporter(f);
		
		//step -2 Create the object of ExtentReports class
		ExtentReports extent = new ExtentReports();
		
		//Step-3  Attach the Reporter
		extent.attachReporter(reporter);
		
		ExtentTest  exLogger = extent.createTest("extentReportDemo");
		
		exLogger.log(Status.INFO, "This is my first info log for the test");
		
		exLogger.log(Status.INFO, "This is my second info log for the test");
		
		exLogger.log(Status.PASS, " The demo testcase is Pass");
		
		
		extent.flush();
		
		
		
		
	}
	

}
