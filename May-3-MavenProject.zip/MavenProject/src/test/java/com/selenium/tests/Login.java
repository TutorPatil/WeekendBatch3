package com.selenium.tests;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.selenium.base.BaseClass;
import com.selenium.utils.Commonutils;

public class Login extends BaseClass {
		
	

	
	@Test
	public static void login_001() throws Exception {
		
		String userName = getTestDataFromMap( "Login", "UserName_TextBox");
		String password = getTestDataFromMap( "Login", "Password_TextBox");
		
		//admin$admin$admin$admin$admin
		//manager$manager$manager$manager$manager
		
		
		System.out.println(userName);
		System.out.println(password);
		
		
		String[] users = userName.split("!");
		
		
		System.out.println(Arrays.toString(users));
		
		String[] passwords = password.split("!");
		
		System.out.println(Arrays.toString(passwords));
		
		for(int i=0; i<users.length;i++)
		{
		
		writeLogs("Got all the test data for login...now trying to login");

		Commonutils.loginToActitime(users[i], passwords[i]);

		boolean result = driver.findElement(By.xpath(getlocatorDataFromMap( "Home", "Logout_Link")))
				.isDisplayed();
		
		Assert.assertTrue(result, "Could not login...login_001 Failed");
		driver.findElement(By.xpath(getlocatorDataFromMap( "Home", "Logout_Link"))).click();
		
		}
				
	}	
	
	
	//@Test
	public static void login_002() throws Exception {
		
		String userName = getDataFromExcelFile("test", "Login", "UserName_TextBox");
		String password = getDataFromExcelFile("test", "Login", "Password_Invalid_TextBox");

		
		Commonutils.loginToActitime(userName, password);

		boolean result = driver.findElement(By.xpath(getlocatorDataFromMap( "Login", "ErrorMsg_Text")))
				.isDisplayed();
		
		Assert.assertTrue(result, " Login_002 Failed...");
		
		
	}
	
	
	

}
