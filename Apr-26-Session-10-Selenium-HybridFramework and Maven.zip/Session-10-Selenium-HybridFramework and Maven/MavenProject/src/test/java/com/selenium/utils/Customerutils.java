package com.selenium.utils;

import com.selenium.base.BaseClass;

public class Customerutils extends BaseClass{

}
