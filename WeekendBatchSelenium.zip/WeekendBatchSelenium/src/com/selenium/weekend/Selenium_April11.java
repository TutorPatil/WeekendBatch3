package com.selenium.weekend;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.common.io.Files;

public class Selenium_April11 {
	
	static WebDriver driver  = null;
	
	enum Module{
		Tasks,
		Reports,
		Users;		
	}
	
	public static void main(String[] args) throws IOException {
		
		
		launchActitime();
		
		
		
		
				
				
		
	}
	
	public static void runJavaScript()
	{
		JavascriptExecutor je = (JavascriptExecutor)driver;
		
		je.executeScript("alert('welcome')");
		
		driver.switchTo().alert().accept();
		
		String title = (String) je.executeScript("return document.title");
		
		System.out.println(title);
		
		long x = (Long) je.executeScript("return document.getElementsByTagName('a').length");
		System.out.println(" The  no of links on the page are"+x);
		
		
		WebElement username = driver.findElement(By.name("username"));
		
		WebElement password = driver.findElement(By.name("pwd"));
		
		WebElement loginBtn = driver.findElement(By.id("loginButton"));
		
		
		je.executeScript("arguments[0].value='admin'", username);
		
		je.executeScript("arguments[0].value='manager'",password);
		
		je.executeScript("arguments[0].click()",loginBtn);
		
		
		je.executeScript("window.open('https://google.com')");
		
		Set<String> str = driver.getWindowHandles();
		
		Iterator<String> itr = str.iterator();
		
		String fwin = itr.next();
		
		String swin = itr.next();
		
		String title1 = driver.switchTo().window(swin).getTitle();
		
		System.out.println(title1);
		
		System.out.println(driver.switchTo().window(fwin).getTitle());
		
		driver.quit();
		
		
		
		
		
		//loginBtn.click();
		
		
		
		
		
		
		
				
		
		
	}
	
	
	public static void captureScreenShot(String fileName) throws IOException
	{
		TakesScreenshot ts = (TakesScreenshot)driver;
		
		//((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		
		File src = ts.getScreenshotAs(OutputType.FILE);
		
		File dest = new File("./screenshots/"+fileName+".png");
		
		Files.copy(src, dest);
		
		
		
		
	}
	
	
	public static void selectModule(String moduleName) throws IOException
	{
		launchActitime();		
		loginToActitime();
		
		String str = "//div[text()='--REPLACETEXT--']/..";
		
		String xpath1 = str.replace("--REPLACETEXT--", moduleName);
		
		
		driver.findElement(By.xpath(xpath1)).click();
		
		
		
		
		
	}
	
	
	public static void usingReplaceInXpath() throws IOException
	{
		
		launchActitime();		
		driver.get("file:///C:/Users/H/Desktop/Bacth3-Jan2020/loginPage.html");
		
		String str = "//td[text()='--REPLACETEXT--']/../td[4]/a";
		
		
		String str1 = str.replace("--REPLACETEXT--", "300");
		
		System.out.println(str1);
		
		String emaiId = driver.findElement(By.xpath(str1)).getText();
		
		System.out.println(emaiId);
		
		
		
		
		
		
	}
	
	
	
	public static void launchActitime() throws IOException
	{
		
		String browser = getConfigData("browser");
		
		System.out.println(browser);
		
		
		
		if (browser.equals("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "./utilities/chromedriver.exe");
			driver = new ChromeDriver();
		}
		
		if (browser.equals("firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "./utilities/geckodriver.exe");
			driver = new FirefoxDriver();
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		driver.get(getConfigData("url"));
	}
	
	
	
	public static String getConfigData(String keyname) throws IOException
	{
		String value = "";
				
		File f = new File("./data/config.properties");	
		FileInputStream fis = new FileInputStream(f);
		
		Properties prop = new Properties();
		prop.load(fis);
		
		value = prop.getProperty(keyname);
					
		return value;
		
		
	}
	
	
	public static void closeBrowser()
	{
		driver.close();
	}
	
	
	public static void loginToActitime()
	{
		
		driver.findElement(By.name("username")).sendKeys("admin");
		driver.findElement(By.name("pwd")).sendKeys("manager");
		
		driver.findElement(By.id("loginButton")).click();
		
		
		
	}
}
