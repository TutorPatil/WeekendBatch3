package com.selenium.weekend;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumBasics {

	static WebDriver driver = null;

	public static void main(String[] args) {

		getTagName();

	}

	public static void getText() {

		launchActitime();

		String linkText = driver.findElement(By.xpath("//a[@id='licenseLink']")).getText();

		System.out.println(" The Tex of the link is " + linkText);

		closeBrowser();

	}

	public static void getAtribute() {

		launchActitime();

		String attValue = driver.findElement(By.xpath("//a[@id='loginButton']")).getAttribute("class");

		System.out.println(" The att value is " + attValue);

		closeBrowser();

	}

	public static void isSelected() {

		launchActitime();

		WebElement checkBox = driver.findElement(By.xpath("//input[@id='keepLoggedInCheckBox']"));

		System.out.println(checkBox.isSelected());

		checkBox.click();

		System.out.println(checkBox.isSelected());

		closeBrowser();

	}

	public static void isEnabled() {

		launchActitime();

		boolean status = driver.findElement(By.xpath("//a[@id='loginButton']")).isEnabled();

		System.out.println("The login btn is enabled --- " + status);

		closeBrowser();

	}

	public static void getTagName() {

		launchActitime();

		String status = driver.findElement(By.xpath("//a[@id='loginButton']")).getTagName();

		System.out.println("The tage name is  --- " + status);

		closeBrowser();

	}

	public static void login001() {
		loginToActitime("admin", "manager");

		boolean logoutStatus = driver.findElement(By.xpath("//a[text()='Logout']")).isDisplayed();

		if (logoutStatus) {
			System.out.println("login001  - PASS");
		} else {
			System.out.println("login001  - FAIL");
		}

		closeBrowser();
	}

	public static void login002() {
		loginToActitime("admin", "manager12");

		// WebElement errormsg =
		// driver.findElement(By.xpath("//span[@class='errormsg']"));

		WebElement errormsg = driver
				.findElement(By.xpath("//span[text()='Username or Password is invalid. Please try again.']"));

		// String msg = errormsg.getText();

		boolean errorMessage = errormsg.isDisplayed();

		if (errorMessage)

		{
			System.out.println("login002  - PASS");
		} else {
			System.out.println("login002  - FAIL");
		}

		closeBrowser();
	}

	public static void loginToActitime(String uname, String pass) {
		launchActitime();

		driver.findElement(By.xpath("//input[@name='username']")).sendKeys(uname);

		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys(pass);

		driver.findElement(By.xpath("//a[@id='loginButton']")).click();

	}

	public static void launchActitime() {
		System.setProperty("webdriver.chrome.driver", "./utilities/chromedriver.exe");

		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		driver.get("http://127.0.0.1:9999/login.do");
	}

	public static void closeBrowser() {
		driver.close();
	}

}
