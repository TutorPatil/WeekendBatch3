package com.selenium.weekend;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.omg.SendingContext.RunTime;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Practice {
	
	static WebDriver driver  = null;
	
	
	public static void main(String[] args) throws IOException, InterruptedException, AWTException {
		
		launchActitime();
		
		driver.get("http://jkorpela.fi/forms/file.html");
		WebElement text = driver.findElement(By.name("textline"));
			
		
		 text.click();
		
	     Actions action = new Actions(driver);
		
		action.sendKeys(text, Keys.TAB).perform();
		
		action.sendKeys(Keys.ENTER).perform();
		
		
		
		Thread.sleep(8000);
		
		File f = new File("filetoupload.txt");
		String text1 = f.getAbsolutePath();
		
		
		
		
		StringSelection stringSelection = new StringSelection(text1);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);

		
		Robot robot = new Robot();
		
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);       
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(4000);
		
	}
	
	public static void mouseOverExample() throws IOException, InterruptedException
	{
		
		launchActitime();
		Actions action = new Actions(driver);
		driver.switchTo().frame("iframeResult");
		
		action.moveToElement(driver.findElement(By.xpath("//div[@class='dropdown']"))).build().perform();

	}
	
	public static void contxtClick() throws IOException, InterruptedException
	{
		
		launchActitime();
		
		WebElement conclick = driver.findElement(By.xpath("//span[@class='context-menu-one btn btn-neutral']"));
		
		Actions action = new Actions(driver);
		
		action.contextClick(conclick).build().perform();
		
		action.sendKeys(Keys.ARROW_DOWN).build().perform();
		
		action.sendKeys(Keys.ENTER).build().perform();
	}
	
	public static void actionExample2() throws IOException, InterruptedException
	{
		
		launchActitime();
		
		loginToActitime();
		
		/*
		 * //driver.get(
		 * "https://www.w3schools.com/html/tryit.asp?filename=tryhtml5_draganddrop");
		 * 
		 * driver.switchTo().frame("iframeResult");
		 * 
		 * WebElement drag = driver.findElement(By.id("drag1"));
		 * 
		 * WebElement drop = driver.findElement(By.id("div1"));
		 * //System.out.println(drag.isDisplayed());
		 * 
		 * //System.out.println(drop.isDisplayed());
		 * 
		 * Actions action = new Actions(driver);
		 * 
		 * //action.clickAndHold(drag).moveToElement(drop).release().build().perform();
		 * 
		 * action.dragAndDrop(drag, drop).build().perform();
		 */
		
	}
	
	public static void actionExample1() throws IOException, InterruptedException
	{
		
		launchActitime();
		
		Actions action = new Actions(driver);
		
		driver.findElement(By.name("username")).click();
		
		action.keyDown(Keys.SHIFT).sendKeys("admin").build().perform();
		
		driver.findElement(By.name("username")).clear();
		
		action.keyUp(Keys.SHIFT).build().perform();
		
		driver.findElement(By.name("username")).sendKeys("admin");
		
		//driver.close();
	}
	
	
	
	
	
	
	
	
	
	public static String getConfigData(String keyname) throws IOException
	{
		String value = "";
				
		File f = new File("./data/config.properties");	
		FileInputStream fis = new FileInputStream(f);
		
		Properties prop = new Properties();
		prop.load(fis);
		
		value = prop.getProperty(keyname);
					
		return value;
		
		
	}
	
	
	public static void closeBrowser()
	{
		driver.close();
	}
	
	public static void launchActitime() throws IOException, InterruptedException
	{
		
		String browser = getConfigData("browser");
		
		System.out.println(browser);
		
		
		
		if (browser.equals("chrome"))
		{
			System.setProperty("webdriver.chrome.silentOutput","true");
			System.setProperty("webdriver.chrome.driver", "./utilities/chromedriver.exe");
			driver = new ChromeDriver();
			
		}
		
		if (browser.equals("firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "./utilities/geckodriver.exe");
			driver = new FirefoxDriver();
		}
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.get(getConfigData("url"));
		
	}
	
	public static void loginToActitime()
	{
		
		driver.findElement(By.name("username")).sendKeys("admin");
		driver.findElement(By.name("pwd")).sendKeys("manager");
		
		driver.findElement(By.id("loginButton")).click();
		
		
		WebDriverWait wait = new WebDriverWait(driver, 20);
		
		wait.until(ExpectedConditions.elementToBeClickable(By.className("logout")));
		
		driver.findElement(By.className("logout")).click();
	}
	
	
	
}
