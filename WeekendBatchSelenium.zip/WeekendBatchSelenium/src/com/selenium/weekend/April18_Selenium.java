package com.selenium.weekend;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.security.auth.callback.LanguageCallback;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.omg.SendingContext.RunTime;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import com.google.common.io.Files;

public class April18_Selenium {
	
	//awt  = Abstract window Toolkit
	
	static WebDriver driver  = null;
	
	
	
	
	public static void main(String[] args) throws Exception {
		
		launchActitime();
		
		loginToActitime();
		
		
	}
	
	
	public static String getLocatorData(String fileName,String pageName, String elementName) throws IOException	
	{
		String locator = "";
		File file = null;
		
		if (fileName.contains("locator"))
		{
			file = new File("./data/locatordata.xlsx");
		}
		else if(fileName.contains("test"))
		{
			file = new File("./data/testdata.xlsx");
		}
		FileInputStream fio = new FileInputStream(file) ;
		
		XSSFWorkbook workbook = new XSSFWorkbook(fio);
		
		XSSFSheet worksheet  = workbook.getSheet("Sheet1");
		
		int rows = worksheet.getLastRowNum();		
		//rows = rows+1;	
		
		for( int x=1; x<=rows;x++ )
		{
			
			String page = worksheet.getRow(x).getCell(0).getStringCellValue();
			String loc = worksheet.getRow(x).getCell(1).getStringCellValue();
			
			if ((pageName.equals(page)) && (elementName.equals(loc)))
					{
						locator = 	worksheet.getRow(x).getCell(2).getStringCellValue();
						break;
					}			
		}		
		workbook.close();
		
		return locator;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	public static void captureScreenShot(String fileName) throws IOException
	{
		TakesScreenshot ts = (TakesScreenshot)driver;
		
		File src = ts.getScreenshotAs(OutputType.FILE);
		
		File dest = new File("./results/screenshot/"+fileName+".png");
		
		Files.copy(src, dest);
		
		
		
		
	}
	
	
	
	
	public static void writeResultsToFile(String testCaseName, String status) throws IOException
	{
		File f = new File("./results/results.txt");
		FileWriter fw = new FileWriter(f,true);
		
		fw.write(testCaseName + "-----"+status);
		
		fw.flush();
		fw.close();
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	public static void uploadFileEx1() throws IOException
	{
		launchActitime();
		driver.get("http://jkorpela.fi/forms/file.html");
		
		File  f = new File("./utilities/filetoupload.txt");
		String filePath = f.getAbsolutePath();
		
		
		driver.findElement(By.name("datafile")).sendKeys(filePath);
	}
	
	
	public static void fileUploadUsingRobot() throws IOException, AWTException, InterruptedException
	{
		launchActitime();
		driver.get("http://jkorpela.fi/forms/file.html");
				
		File  f = new File("./utilities/filetoupload.txt");
		String filePath = f.getAbsolutePath();
		
		
		WebElement file = driver.findElement(By.name("datafile"));
		
		Actions action = new Actions(driver);
		
		action.click(file).build().perform();
		
		Thread.sleep(4000);
		
		StringSelection stringSelection = new StringSelection(filePath);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);

		Robot robot = new Robot();
		
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_ENTER);
		
		
		
		
		
		//driver.findElement(By.name("datafile")).sendKeys(filePath);
	}
	

	public static void ieUploadinUsingAutoIT() throws IOException, InterruptedException
	{
		
		launchActitime();
		driver.get("http://jkorpela.fi/forms/file.html");
				
		File  f = new File("./utilities/FileUploadAutoIT.exe");
		String filePath = f.getAbsolutePath();
		
		
		WebElement file = driver.findElement(By.name("datafile"));
		
		Actions action = new Actions(driver);
		
		action.click(file).build().perform();
		
		Thread.sleep(4000);
		
		Runtime.getRuntime().exec(filePath);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public static void launchActitime() throws IOException
	{
		
		String browser = getConfigData("browser");
		
			
		
		if (browser.equals("chrome"))
		{
			System.setProperty("webdriver.chrome.silentOutput","true");
			System.setProperty("webdriver.chrome.driver", "./utilities/chromedriver.exe");
			driver = new ChromeDriver();
			
			//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		}
		
		if (browser.equals("firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "./utilities/geckodriver.exe");
			driver = new FirefoxDriver();
		}
		
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.get(getConfigData("url"));
		
		
		
	}
	
	
	
	public static String getConfigData(String keyname) throws IOException
	{
		String value = "";
				
		File f = new File("./data/config.properties");	
		FileInputStream fis = new FileInputStream(f);
		
		Properties prop = new Properties();
		prop.load(fis);
		
		value = prop.getProperty(keyname);
					
		return value;
		
		
	}
	
	
	public static void closeBrowser()
	{
		driver.close();
	}
	
	
	public static boolean loginToActitime() throws IOException
	{
		
		driver.findElement(By.xpath(getLocatorData("locator","Login", "UserName_TextBox")))
		.sendKeys(getLocatorData("test", "Login", "UserName_TextBox"));
		
		driver.findElement(By.xpath(getLocatorData("locator","Login", "Password_TextBox"))).
		sendKeys(getLocatorData("test", "Login", "Password_TextBox"));
		
		driver.findElement(By.xpath(getLocatorData("locator","Login", "Ok_Button"))).click();
		
		return false;
		
		//JavascriptExecutor je = (JavascriptExecutor)driver;
		
		//je.executeScript("alert('welcome')");
		
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		/*
		
		WebDriverWait wait = new WebDriverWait(driver, 5);		
		wait.until(ExpectedConditions.elementToBeClickable(By.className("Logout")));
		*/
		
		
		//wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//a[text()='Logout']"))));
		//wait.until(ExpectedConditions.alertIsPresent());
		
		
		
		
		
	}

	
	

}
