package com.selenium.weekend;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumNestedInterfaceMethods {
	
	static WebDriver driver  = null;
	
	public static void main(String[] args) throws InterruptedException {
		
		handlePopUp();
	}
	
	public static void handlePopUp() throws InterruptedException
	{
		
		launchActitime();
		
		driver.get("https://erail.in/");
		
		driver.findElement(By.xpath("//a[@title='View the route of the train on the map']")).click();
		
		Thread.sleep(2000);
		
		WebDriver.TargetLocator wt = driver.switchTo();
		
		Alert aler = wt.alert();
		
		aler.accept();
		
		//driver.switchTo().alert().accept();
		
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//a[@title='View the route of the train on the map']")).click();
		
		String alertText = driver.switchTo().alert().getText();
		
		System.out.println(" The Text on the alert is " +alertText );
		
	}
	
	
	public static void navigationsMethods() throws InterruptedException
	{
		launchActitime();
		
		Thread.sleep(2000);
		
		driver.get("https://google.com");
		
		Thread.sleep(2000);
		
		WebDriver.Navigation wn = driver.navigate();
		
		//driver.navigate().back();
		
		wn.back();
		
		Thread.sleep(2000);
		
		wn.forward();
		
		Thread.sleep(2000);
		
		wn.refresh();
				
		Thread.sleep(2000);
		
		wn.to("https://mail.yahoo.com");
		
		Thread.sleep(2000);
		
		closeBrowser();
	}

	
	
	public static void windowMaximizeEtc() throws InterruptedException
	{
				
		launchActitime();
		
		// Maximize
		WebDriver.Options wo = driver.manage();
		
		WebDriver.Window ww = wo.window();
		
		ww.maximize();
		
		//driver.manage().window().maximize();
		
		// Minimize or hide
		Point p = new Point(-3000,300);
		
		driver.manage().window().setPosition(p);
		
		Thread.sleep(2000);
		
		driver.manage().window().maximize();
		
		Thread.sleep(2000);
		
		// set window size
		
		Dimension d = new Dimension(50,50);
		
		driver.manage().window().setSize(d);
		
		Thread.sleep(2000);
		
		Point p1 = new Point(200,200);
		
		driver.manage().window().setPosition(p1);
		
	}
	
	public static void launchActitime()
	{
		System.setProperty("webdriver.chrome.driver", "./utilities/chromedriver.exe");
		
		driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		driver.get("http://127.0.0.1:9999/login.do");
	}
	
	
	public static void closeBrowser()
	{
		driver.close();
	}
	
	
	
}
