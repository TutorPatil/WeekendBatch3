package com.selenium.weekend;

import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SeleniumApril5 {

	static WebDriver driver  = null;
	
	public static void main(String[] args) throws InterruptedException {
	
		multiSelctExample();
	}
	
	
	public static void byClassLocators()
	{
		
		launchActitime();
		
		driver.findElement(By.name("username")).sendKeys("admin");
		
		driver.findElement(By.id("loginButton")).click();
		
		driver.findElement(By.linkText("Actimind Inc.")).getText();
		
		
		driver.findElement(By.partialLinkText("Actimind")).getText();
		
		driver.findElement(By.tagName("button")).click();
		
		
//		X path and CSS differences
		//input[@name='username']  ---- input[name='username']
		
		//a[@id='loginButton']  --- a[id='loginButton'] -- a#loginButton --- #loginButton
		
		//table[@class='footer']/tbody/tr/td[2]/nobr/a  --- .footer tbody  tr td:nth-child(2) a
		
		
		
		
	}
	
	
	public static void dropDownHandling1() throws InterruptedException
	{
		launchActitime();
		
		driver.get("file:///C:/Users/H/Desktop/Bacth3-Jan2020/loginPage.html");
		
		WebElement carSelect = driver.findElement(By.xpath("//select[@id='cardrpdown']"));
		
		Select select = new Select(carSelect);
		
		
		// To find out no of items in the combo box
		
		List<WebElement> items = select.getOptions();
		
		
		System.out.println(" The no of items in the drop down are "+items.size());
		
		for( int x = 0; x<items.size();x++)
		{
			String s = items.get(x).getText();
			System.out.println(s);
		}
		
		// To select an item from the dropdown		
		select.selectByVisibleText("Opel");
		
		Thread.sleep(2000);
		
		select.selectByValue("volvo");
		
		Thread.sleep(2000);
		
		
		select.selectByIndex(3);
		
		
		// To check which item is selected
		
		WebElement item = 	select.getFirstSelectedOption();
		
		System.out.println(item.getText());
		
		
		driver.quit();
		
	}
	
	public static void multiSelctExample() throws InterruptedException
	{

		launchActitime();
		
		driver.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml_select_multiple");
		
		driver.switchTo().frame("iframeResult");
		
		WebElement carSelect = driver.findElement(By.xpath("//select[@id='cars']"));
		
		Select select = new Select(carSelect);
		
		System.out.println(select.isMultiple());
		
		select.selectByVisibleText("Opel");
		
		Thread.sleep(2000);
		select.selectByVisibleText("Volvo");
		Thread.sleep(2000);
		
		// To get all the  items from the multi select list
		select.getOptions();
		
		List<WebElement> items = select.getAllSelectedOptions();
		
		for( int x = 0; x<items.size();x++)
		{
			String s = items.get(x).getText();
			System.out.println(s);
		}
		
		
		
		select.deselectByVisibleText("Opel");
		Thread.sleep(2000);
		
		
		select.deselectAll();
		
		Thread.sleep(2000);
		
		
	
		
		
		
		driver.quit();
		
	
		
	}
	
	public static void findElementsExample2()
	{
		launchActitime();
		
		driver.get("file:///C:/Users/H/Desktop/Bacth3-Jan2020/loginPage.html");
		
		List<WebElement> sNames = driver.findElements(By.xpath("//table/tbody/tr/td[2]"));
		
		for( int x=0; x<sNames.size();x++)
		{
			String link = sNames.get(x).getText();
			
			System.out.println(link);
		}
		
		
	}
	
	public static void multipleWindowHandling()
	{
		
		launchActitime();
		
		String winId = driver.getWindowHandle();
		
		System.out.println(winId);
		
		driver.findElement(By.xpath("//a[@href='http://www.actimind.com']")).click();
		
		Set<String> winIds = driver.getWindowHandles();
		
		Iterator<String> itr = winIds.iterator();
		
		String windId1 = itr.next();
		String windId2 =itr.next();
		
		String fWindowId = "";
		
		if (winId.equals(windId1))
		{
			 fWindowId = windId1;
		}
		
		String sWindowId = windId2;
		
		System.out.println("first window title " +driver.getTitle());
		
		driver.switchTo().window(sWindowId);
		
		System.out.println("Second window titl"+driver.getTitle());
		
		driver.quit();
		
		//driver.close();
		
		//driver.switchTo().window(fWindowId);
		
		//driver.close();
		
		
	}
	
	public static void test()
	{
		
		launchActitime();
		
		driver.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml_select_multiple");
		
		//switch to Frame using frame index 0,1,2,
		driver.switchTo().frame(0);
		
		
		//Switch using Id or name
		//driver.switchTo().frame("iframeResult");
		
	  
	  
	  // swicth using webElement
		//WebElement frame1=driver.findElement(By.xpath("//iframe[@id='iframeResult']"));
		//driver.switchTo().frame(frame1);
	
	
		
		System.out.println(driver.findElement(By.xpath("//select[@id='cars']/../input")).isDisplayed());
		
		// swiching back to main html page away from frame
		driver.switchTo().defaultContent();
		
		
		
		
	}
	
	public static void findElementsExample()
	{
		launchActitime();
		
		driver.get("https://www.google.com/");
		
		List<WebElement> links  = driver.findElements(By.xpath("//a"));
		
		System.out.println("no of links = "+links.size());
		
		for( int x=0; x<links.size();x++)
		{
			String link = links.get(x).getText();
			
			System.out.println(link);
		}
		
		driver.findElement(By.xpath("//input[@name='q']")).sendKeys("Download Selenium");
		
		driver.findElement(By.xpath("//div[@class='tfB0Bf']/center/input[1]")).click();
		
		List<WebElement> searchLinks = driver.findElements(By.xpath("//h3"));
		
		for( int x=0; x<searchLinks.size();x++)
		{
			String link = searchLinks.get(x).getText();
			
			System.out.println(link);
		}
		
		//driver.findElements(By.xpath("//input[@name='username']"));
		
		//driver.findElement(By.xpath("//input"));
		
		//driver.quit();
		
		
		// No of Students in the Table 
		
		
		
		
	}
	

	public static void launchActitime()
	{
		System.setProperty("webdriver.chrome.silentOutput","true");
		System.setProperty("webdriver.chrome.driver", "./utilities/chromedriver.exe");
		
		driver = new ChromeDriver();
		
	

		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		driver.get("http://127.0.0.1:9999/login.do");
	}
	
	
	public static void closeBrowser()
	{
		driver.close();
	}
	

}
