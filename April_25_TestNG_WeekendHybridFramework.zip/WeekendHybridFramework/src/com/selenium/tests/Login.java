package com.selenium.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.selenium.base.BaseClass;
import com.selenium.utils.Commonutils;

public class Login extends BaseClass {
		

	// @Test(groups = {"smoke", "Regression","login","login_001"} )
	
	@Parameters({ "username","password" })
	@Test
	public static void login_001(String  user, String pass) throws Exception {
		
		//String userName = getDataFromExcelFile("test", "Login", "UserName_TextBox");
		//String password = getDataFromExcelFile("test", "Login", "Password_TextBox");

		
		Commonutils.loginToActitime(user, pass);

		boolean result = driver.findElement(By.xpath(getDataFromExcelFile("locator", "Home", "Logout_Link")))
				.isDisplayed();
		
		Assert.assertTrue(result, "Could not login...login_001 Failed");
		writeResultsToFile("login_001", "Pass");
		
		
		//Assert.assertFalse(result, "Could not login...login_001 Failed");
		
		
		/*
		int expectedCount = 20;		
		int actulCount = 20;
		
		Assert.assertEquals(actulCount, expectedCount,"The actual count is not as expected...");		
		String exectedTitle = "actiTIME - Enter Time-Track";
		
		String actualTile =   driver.getTitle();		
		Assert.assertEquals(actualTile, exectedTitle,"The titles do  not match,,,,");
	*/
		
	}
	
	

	
	 //@Test(groups = {"smoke","Regression","login","login_002"} )
	// @Test
	public static void login_002() throws Exception {
		
		String userName = getDataFromExcelFile("test", "Login", "UserName_TextBox");
		String password = getDataFromExcelFile("test", "Login", "Password_Invalid_TextBox");

		
		Commonutils.loginToActitime(userName, password);

		boolean result = driver.findElement(By.xpath(getDataFromExcelFile("locator", "Login", "ErrorMsg_Text")))
				.isDisplayed();
		
		Assert.assertTrue(result, " Login_002 Failed...");
		writeResultsToFile("login_003", "Pass");
		
	}
	
	

	
	
	
	
	
	
	
	//@Test
	public static void login_003()  {
		boolean result = false;	
		try {
			
		
		String userName = getDataFromExcelFile("test", "Login", "UserName_Invalid_TextBox");
		String password = getDataFromExcelFile("test", "Login", "Password_TextBox");

		
		Commonutils.loginToActitime(userName, password);
		result = driver.findElement(By.xpath(getDataFromExcelFile("locator", "Login", "ErrorMsg_Text")))
				.isDisplayed();
		
		Assert.assertTrue(result, "Could not login...login_002 Failed");
		writeResultsToFile("login_002", "Pass");
		}
		catch(Exception ne)
		{
			System.out.println("The error message was not seen");	
			ne.printStackTrace();			
			try {
				Assert.assertTrue(result, "Could not login...login_002 Failed");
				writeResultsToFile("login_002", "Fail");
				captureScreenShot("login_002");
			} catch (Exception e) {				
				e.printStackTrace();
			}
		}
		
		
	}
	

}
