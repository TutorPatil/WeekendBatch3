package com.selenium.tests;

import com.selenium.base.BaseClass;

public class Projects extends BaseClass{

}
