package com.selenium.tests;

public class Runner {

	public static void main(String[] args) throws Exception {
	
	
		//Login.login_001();
		//Login.login_002();
		//Login.login_003();

	}

}
