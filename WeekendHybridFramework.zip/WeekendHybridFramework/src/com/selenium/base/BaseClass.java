package com.selenium.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.common.io.Files;

public class BaseClass {

	public static WebDriver driver = null;
	
	//***************************************************************************************
	
	/**
	 * Title This method is for reading the config Data
	 * @author Patil
	 * @param keyname
	 * @return PropertyValue
	 * @throws Exception
	 */
	
	public static String getConfigData(String keyname) throws Exception {
		String value = "";

		File f = new File("./data/config.properties");
		FileInputStream fis = new FileInputStream(f);

		Properties prop = new Properties();
		prop.load(fis);

		value = prop.getProperty(keyname);

		return value;

	}
	
	//***************************************************************************************

	/**
	 * Title : - This method is to launch the Actitime Application
	 * @author Patil
	 * @throws Exception
	 * @param none
	 */
	
	
	public static void launchActitime() throws Exception {

		String browser = getConfigData("browser");

		if (browser.equals("chrome")) {
			System.setProperty("webdriver.chrome.silentOutput", "true");
			System.setProperty("webdriver.chrome.driver", "./tools/chromedriver.exe");
			driver = new ChromeDriver();

		}

		if (browser.equals("firefox")) {
			System.setProperty("webdriver.gecko.driver", "tools/geckodriver.exe");
			driver = new FirefoxDriver();
		}

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.get(getConfigData("url"));
	}
	
	//***************************************************************************************

	/**
	 * Title : - This method is to close the Actitime Application
	 * @author Patil
	 * @throws none
	 * @param none
	 * @return none
	 * 
	 */
	
	public static void closeBrowser() {
		driver.close();
	}
	
	//***************************************************************************************
	
	/**
	 * Title : - This method is to write results to a txt file
	 * @author Patil
	 * @throws Exception
	 * @Param testCaseName, status
	 * @return none
	 * 
	 */

	
	public static void writeResultsToFile(String testCaseName, String status) throws Exception {
		File f = new File("results/results.txt");
		FileWriter fw = new FileWriter(f, true);

		fw.write(testCaseName + "-----" + status+"\n");

		fw.flush();
		fw.close();

	}
	
	//***************************************************************************************
	
	/**
	 * Title : - This method is to capture  the screenshots of failed tests
	 * @author Patil
	 * @throws Exception
	 * @Param fileName
	 * @return none
	 * 
	 */

	public static void captureScreenShot(String fileName) throws IOException {
		TakesScreenshot ts = (TakesScreenshot) driver;
		File src = ts.getScreenshotAs(OutputType.FILE);
		File dest = new File("./results/screenshot/" + fileName + ".png");
		Files.copy(src, dest);

	}

	//***************************************************************************************
	/**
	 * Title : - This method is to fetch locatordata and test data from excel file
	 * @author Patil
	 * @throws Exception
	 * @Param fileName,pageName,elementName
	 * @return locator or Test data
	 * 
	 */
	
	
	public static String getDataFromExcelFile(String fileName, String pageName, String elementName) throws Exception {
		String locator = "";
		File file = null;

		if (fileName.contains("locator")) {
			file = new File("./data/locatordata.xlsx");
		} else if (fileName.contains("test")) {
			file = new File("./data/testdata.xlsx");
		}
		FileInputStream fio = new FileInputStream(file);

		XSSFWorkbook workbook = new XSSFWorkbook(fio);

		XSSFSheet worksheet = workbook.getSheet("Sheet1");

		int rows = worksheet.getLastRowNum();
		// rows = rows+1;

		for (int x = 1; x <= rows; x++) {

			String page = worksheet.getRow(x).getCell(0).getStringCellValue();
			String loc = worksheet.getRow(x).getCell(1).getStringCellValue();

			if ((pageName.equals(page)) && (elementName.equals(loc))) {
				locator = worksheet.getRow(x).getCell(2).getStringCellValue();
				break;
			}
		}
		workbook.close();

		return locator;

	}
	
	//***************************************************************************************

}
