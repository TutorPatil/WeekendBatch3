package com.selenium.tests;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.selenium.base.BaseClass;
import com.selenium.utils.Commonutils;

public class Login extends BaseClass {

	@Test
	public static void login_001() throws Exception {
		String userName = getDataFromExcelFile("test", "Login", "UserName_TextBox");
		String password = getDataFromExcelFile("test", "Login", "Password_TextBox");

		launchActitime();
		Commonutils.loginToActitime(userName, password);

		boolean result = driver.findElement(By.xpath(getDataFromExcelFile("locator", "Home", "Logout_Link")))
				.isDisplayed();
		
		if (result) {
			writeResultsToFile("login_001", "Pass");
		} else {
			writeResultsToFile("login_001", "Fail");
			captureScreenShot("login_001");
		}
		closeBrowser();
	}
	
	
	@Test
	public static void login_002() throws Exception {
		String userName = getDataFromExcelFile("test", "Login", "UserName_Invalid_TextBox");
		String password = getDataFromExcelFile("test", "Login", "Password_TextBox");

		launchActitime();
		Commonutils.loginToActitime(userName, password);

		boolean result = driver.findElement(By.xpath(getDataFromExcelFile("locator", "Login", "ErrorMsg_Text")))
				.isDisplayed();
		
		if (result) {
			writeResultsToFile("login_002", "Pass");
		} else {
			writeResultsToFile("login_002", "Fail");
			captureScreenShot("login_002");
		}
		closeBrowser();
	}
	
	
	
	@Test
	public static void login_003() throws Exception {
		String userName = getDataFromExcelFile("test", "Login", "UserName_TextBox");
		String password = getDataFromExcelFile("test", "Login", "Password_Invalid_TextBox");

		launchActitime();
		Commonutils.loginToActitime(userName, password);

		boolean result = driver.findElement(By.xpath(getDataFromExcelFile("locator", "Login", "ErrorMsg_Text")))
				.isDisplayed();
		
		if (result) {
			writeResultsToFile("login_003", "Pass");
		} else {
			writeResultsToFile("login_003", "Fail");
			captureScreenShot("login_003");
		}
		closeBrowser();
	}
	

}
